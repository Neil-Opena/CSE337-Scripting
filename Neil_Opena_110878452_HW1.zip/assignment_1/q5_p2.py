#Password Check
#Part 2

username = input("Username: ")

while(True):
    password = input("Password: ")
    print("Password is not strong enough.")